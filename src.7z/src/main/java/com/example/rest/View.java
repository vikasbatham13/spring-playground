package com.example.rest;


public class View {
   public interface Summary {}
}
